async function handleTranslate() {
  const text = document.getElementById("inputText").value;
  const targetLang = document.getElementById("language").value;
  const provider = document.getElementById("provider").value;
  const response = await fetch(`/.netlify/functions/${provider}`, {
    method: "POST",
    body: JSON.stringify({ text, targetLang }),
  });
  const data = await response.json();
  document.getElementById("result").textContent = data.translation || "Translation failed.";
}