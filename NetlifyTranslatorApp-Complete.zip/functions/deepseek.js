export async function handler(event) {
  const { text, targetLang } = JSON.parse(event.body);
  const apiKey = process.env.DEEPSEEK_API_KEY;

  const response = await fetch("https://api.deepseek.com/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${apiKey}`,
    },
    body: JSON.stringify({
      model: "deepseek-chat",
      messages: [{ role: "user", content: `Translate this into ${targetLang}: ${text}` }],
    }),
  });

  const result = await response.json();
  return {
    statusCode: 200,
    body: JSON.stringify({ translation: result.choices[0].message.content }),
  };
}