export async function handler(event) {
  const { text, targetLang } = JSON.parse(event.body);
  const apiKey = process.env.DEEPL_API_KEY;

  const response = await fetch("https://api-free.deepl.com/v2/translate", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({
      auth_key: apiKey,
      text,
      target_lang: targetLang.toUpperCase(),
    }),
  });

  const result = await response.json();
  return {
    statusCode: 200,
    body: JSON.stringify({ translation: result.translations[0].text }),
  };
}